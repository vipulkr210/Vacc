package connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class JDBCConnection
{

    public Connection con;

    public JDBCConnection()
    {
    }
    public Connection connect()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/vacc", "root", "root");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return con;
    }
}
