package doctor;

import java.util.List;

// Referenced classes of package doctor:
//            DoctorBean

public interface DoctorInterface
{

    public abstract void addDoctor(Doctor doctor);

    public abstract List listDoctor(String s);

    public abstract void deleteDoctor(int i);

    public abstract void editDoctor(int i, Doctor doctor);
}
