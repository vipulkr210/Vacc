package doctor;

import connection.HibernateConnection;
import java.io.*;
import java.util.Iterator;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import org.hibernate.*;
@WebServlet("/doctorlogin")
public class DoctorLogin extends HttpServlet
{

    private static final long serialVersionUID = 1L;

    public DoctorLogin()
    {
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String emaildoctor = request.getParameter("emaildoctor");
        boolean b = false;
        int did = 0;
        Session sess = HibernateConnection.getSessionFactory().openSession();
        Query query = sess.createQuery((new StringBuilder("select id from Doctor where  email='")).append(emaildoctor).append("'").toString());
        List list = query.list();
        if(list.size() > 0)
        {
            b = true;
        }
        for(Iterator iterator = list.iterator(); iterator.hasNext(); System.out.println(did))
        {
            did = ((Integer)iterator.next()).intValue();
        }

        if(b)
        {
            HttpSession session = request.getSession();
            session.setAttribute("did", Integer.valueOf(did));
            session.setAttribute("mac", "Doctor");
            session.setAttribute("emaildoctor", emaildoctor);
            RequestDispatcher rd = request.getRequestDispatcher("ViewDoctor.jsp");
            rd.include(request, response);
      
        }
        if(!b)
        {
            RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
            rd.include(request, response);
        }
    }
}
