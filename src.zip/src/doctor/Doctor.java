package doctor;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity @Table(name="Doctor")
public class Doctor
{
@Id @GeneratedValue(strategy=GenerationType.AUTO)
    private int did;
    private String name;
    private String fname;
    private String lname;
    private String mobile;
    private String address;
    private String email;
    private String degree;
    private String username;
    private String password;
    private String dateadded;
    private String aadharnum;
    private String city;
    private String pincode;
    private String state;
    private String hiqualification;
    private String percentage;
    private String passyear;
    private String university;
    private Date dob;
public Doctor() {
	
}
  
    public Doctor(String name, String fname, String lname, String mobile, String address, String email, String username,
		String password, String dateadded, String aadharnum, String city, String pincode, String state,
		String hiqualification, String percentage, String passyear, String university, Date dob) {
	super();
	this.name = name;
	this.fname = fname;
	this.lname = lname;
	this.mobile = mobile;
	this.address = address;
	this.email = email;
	this.username = username;
	this.password = password;
	this.dateadded = dateadded;
	this.aadharnum = aadharnum;
	this.city = city;
	this.pincode = pincode;
	this.state = state;
	this.hiqualification = hiqualification;
	this.percentage = percentage;
	this.passyear = passyear;
	this.university = university;
	this.dob = dob;
}

	public Doctor(int did, String email) {
		super();
		this.did = did;
		this.email = email;
	}

	public Doctor(String email, String username, String password) {
		super();
		this.email = email;
		this.username = username;
		this.password = password;
	}

	public Doctor(int did, String name, String fname, String lname, String mobile, String address,
			 String aadharnum, String city, String pincode, String state, String hiqualification,
			String percentage, String passyear, String university) {
		super();
		this.did = did;
		this.name = name;
		this.fname = fname;
		this.lname = lname;
		this.mobile = mobile;
		this.address = address;
		this.aadharnum = aadharnum;
		this.city = city;
		this.pincode = pincode;
		this.state = state;
		this.hiqualification = hiqualification;
		this.percentage = percentage;
		this.passyear = passyear;
		this.university = university;
	}

	public String getDateadded()
    {
        return dateadded;
    }

    public void setDateadded(String dateadded)
    {
        this.dateadded = dateadded;
    }

    public int getDid()
    {
        return did;
    }

    public void setDid(int did)
    {
        this.did = did;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getFname()
    {
        return fname;
    }

    public void setFname(String fname)
    {
        this.fname = fname;
    }

    public String getLname()
    {
        return lname;
    }

    public void setLname(String lname)
    {
        this.lname = lname;
    }

    public String getMobile()
    {
        return mobile;
    }

    public void setMobile(String mobile)
    {
        this.mobile = mobile;
    }

    public String getAddress()
    {
        return address;
    }

    public void setAddress(String address)
    {
        this.address = address;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public Date getDob()
    {
        return dob;
    }

    public void setDob(Date dob)
    {
        this.dob = dob;
    }

    public String getDegree()
    {
        return degree;
    }

    public void setDegree(String degree)
    {
        this.degree = degree;
    }

    public String getUsername()
    {
        return username;
    }

    public void setUsername(String username)
    {
        this.username = username;
    }

    public String getPassword()
    {
        return password;
    }

    public void setPassword(String password)
    {
        this.password = password;
    }

    public String getAadharnum()
    {
        return aadharnum;
    }

    public void setAadharnum(String aadharnum)
    {
        this.aadharnum = aadharnum;
    }

    public String getCity()
    {
        return city;
    }

    public void setCity(String city)
    {
        this.city = city;
    }

    public String getPincode()
    {
        return pincode;
    }

    public void setPincode(String pincode)
    {
        this.pincode = pincode;
    }

    public String getState()
    {
        return state;
    }

    public void setState(String state)
    {
        this.state = state;
    }

    public String getHiqualification()
    {
        return hiqualification;
    }

    public void setHiqualification(String hiqualification)
    {
        this.hiqualification = hiqualification;
    }

    public String getPercentage()
    {
        return percentage;
    }

    public void setPercentage(String percentage)
    {
        this.percentage = percentage;
    }

    public String getPassyear()
    {
        return passyear;
    }

    public void setPassyear(String passyear)
    {
        this.passyear = passyear;
    }

    public String getUniversity()
    {
        return university;
    }

    public void setUniversity(String university)
    {
        this.university = university;
    }

    public String toString()
    {
        return super.toString();
    }
}
