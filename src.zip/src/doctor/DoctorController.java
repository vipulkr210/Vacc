package doctor;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import parent.Parent;


@WebServlet("/doc")
public class DoctorController extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	DoctorImpl di;
    Doctor db;

    public DoctorController()
    {
        di = new DoctorImpl();
        db = new Doctor();
    }

    @SuppressWarnings("unchecked")
	public void doPost(HttpServletRequest req, HttpServletResponse res)
        throws IOException, ServletException
    {
        res.setContentType("text/html");
       HttpSession session=req.getSession();
        String t = req.getParameter("t");
        String fname = req.getParameter("fname");
        String pid = req.getParameter("pid");
         String lname = req.getParameter("lname");
        String name = (new StringBuilder(String.valueOf(fname))).append(" ").append(lname).toString();
        String email = req.getParameter("email");
        String mobile = req.getParameter("mobile");
        String city = req.getParameter("city");
        String address = req.getParameter("address");
        String id = req.getParameter("id");
        String pincode = req.getParameter("pincode");
        String aadharnum = req.getParameter("aadharnum");
        String dob = req.getParameter("dob");
        String percentage = req.getParameter("percentage");
        String university = req.getParameter("university");
        String password = req.getParameter("password");
         String hiqualification = req.getParameter("hiqualification");
        String state = req.getParameter("state");
        String passyear = req.getParameter("passyear");
        DateFormat sf = new SimpleDateFormat("dd/MM/yyyy");
        db.setEmail(email);
       
        
        if(t != null) {if( t.equals("addDoctor"))
        {
            try
            { 
            	Doctor doctor=new Doctor(name, fname, lname, mobile, address, email, email, password, sf.format(new Date()), aadharnum, city, pincode, state, hiqualification, percentage, passyear, university, sf.parse(dob));
            	
                 di.addDoctor(doctor);
                System.out.println("Doctor added from Controller ");
                RequestDispatcher rd = req.getRequestDispatcher("AddDoctor.jsp?fid=2");
                rd.forward(req, res);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        
        if(t.equals("updateDoctor"))
        {
            try
            {Doctor d0ctor=new Doctor(Integer.parseInt(id), name, fname, lname, mobile, address, aadharnum, city, pincode, state, hiqualification, percentage, passyear, university);
             int a= di.updateDoctor(d0ctor);
              if(a==0) {
                  System.out.println("Parent Updated ");
                  List<Doctor> l=di.listDoctor(email);
             	 for(Doctor par: l) {
             		 session.setAttribute("did",par.getDid());
                  session.setAttribute("mac", "Doctor");
                  session.setAttribute("email", email);
                  ServletContext context=req.getServletContext();
                  context.setAttribute("listDoctor", l);
                 
                  RequestDispatcher rd = req.getRequestDispatcher("EditDoctor.jsp?fid=2");
                  rd.forward(req, res);
                }
             	 }
              else {
                  System.out.println("Not Updated ");
                  RequestDispatcher rd = req.getRequestDispatcher("EditDoctor.jsp?fid=4");
                  rd.forward(req, res);
                }
              
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        
        if(t.equals("login"))
        {
            try
            {Doctor doctor=new Doctor(email, email, password);
                List<Doctor> login=di.login(doctor);
                if(login.size()>0) {
               	 List<Doctor> l=di.listDoctor(email);
               	 for(Doctor par: l) {
               		 session.setAttribute("pname",par.getName());
               		 session.setAttribute("cname",par.getName());
                		 session.setAttribute("pid",par.getDid());
                     session.setAttribute("mac", "Doctor");
                    session.setAttribute("email", par.getEmail());
               	 }
                    RequestDispatcher rd = req.getRequestDispatcher("doc?t=viewdoc");
                    rd.forward(req, res);
                    }
                if(login.size()==0) {
                    RequestDispatcher rd = req.getRequestDispatcher("index.jsp");
                    rd.forward(req, res);
                    }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }

        
        if(t.equals("viewdoc"))
        {
            List<Doctor> list = new ArrayList<Doctor>();
            list = di.listDoctor(email);
            ServletContext context=req.getServletContext();
            context.setAttribute("listDoctor", list);
            RequestDispatcher rd1 = req.getRequestDispatcher("ViewDoctor.jsp");
            rd1.forward(req, res);
        }
    
        
        if(t.equals("viewCertificate"))
        {
            List<Parent> list = new ArrayList<Parent>();
            list = di.listCertificate(pid);
            req.setAttribute("listCertificate", list);
            RequestDispatcher rd1 = req.getRequestDispatcher("ViewCertificate.jsp");
            rd1.forward(req, res);
        }
    
        }
    }
}
