package doctor;

import connection.HibernateConnection;
import parent.Parent;

import java.io.PrintStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.hibernate.*;

// Referenced classes of package doctor:
//            Doctor, DoctorBean

public class DoctorImpl
    implements DoctorInterface
{
	static  Properties props = new Properties();
	static{
		
		
	        props.put("mail.smtp.auth", "true");
	        props.put("mail.smtp.host", "smtp.gmail.com");
	        props.put("mail.smtp.port", "465");
	        props.put("mail.transport.protocol", "smtp");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

	}
	 public List<Doctor> login(Doctor doctor) {
	    	Session sess = HibernateConnection.getSessionFactory().openSession();
	        Query query = sess.createQuery("from Doctor where  email='"+doctor.getEmail()+"' ");
	        List<Doctor> list=query.list();
	        
	    	return list;
	    }
    public void addDoctor(Doctor pb)
    {
        Session sess = HibernateConnection.getSessionFactory().openSession();
        Transaction t = sess.beginTransaction();
        sess.save(pb);
        t.commit();
        System.out.println("Doctor Added Succesfully : "+pb.getName());
        sess.close();
        try{int p=0;
      		try {
      		URL url=new URL("http://google.co.in");
      		URLConnection conn=url.openConnection();
      		conn.connect();
      		}catch(Exception e) {p=1;
      		System.out.println("No Internet Connection");}
      		if(p==0) {
      		String from="infinobell@gmail.com",password="Extreme444@";
      		System.out.println( from+"    	 "+password );
      		javax.mail.Session session = javax.mail.Session.getDefaultInstance(props,
      				new javax.mail.Authenticator() {
      				protected PasswordAuthentication
      				getPasswordAuthentication() {
      				return new
      				PasswordAuthentication(from , password);
      				}});
      				Message message = new MimeMessage(session);
      				String body="Welcome "+pb.getName()+"<br>We are happy to see you at Infinobell.<br>Please Click Below link to verify your profile. to Login";
      				String f="<form action='http://infinobell.com/student?sub=verify&email="+pb.getEmail()+"&password="+pb.getPassword()+"'></form>";
      				message.setFrom (new InternetAddress(from ));
      				message.setRecipients(Message.RecipientType.TO,
      				InternetAddress.parse(pb.getEmail()));
      				message.setSubject("Congratulations -"+pb.getName()+" Welcome to Vaccination Portal");
      				message.setContent(body,"text/html");
      				Transport.send(message);
      				  
      				System.out.println("Email too "+pb.getEmail()+"  is Sent by  "+from+" . ");
      		}  
      	}catch(Exception e) {}
            
    }

    public List listDoctor(String emaildoctor)
    {
        List list = new ArrayList();
        Session sess = HibernateConnection.getSessionFactory().openSession();
        Query query = sess.createQuery((new StringBuilder("from Doctor where email='")).append(emaildoctor).append("'").toString());
        list = query.list();
        sess.close();
        return list;
    }

    public void deleteDoctor(int i)
    {
    }

    public void editDoctor(int i, Doctor doctor)
    {
    }
	public int updateDoctor(Doctor db) {
		int ad=0;
	    Session sess = HibernateConnection.getSessionFactory().openSession();
	         Doctor p = (Doctor)sess.load(Doctor.class, db.getDid());
	        sess.update(db);
	        
	        sess.beginTransaction().commit();
	        System.out.println("Doctor Updated Succesfully : "+db.getName());
	        
	         
	        sess.close();
	   return ad;
	}
	public List<Parent> listCertificate(String id) {
		List<Parent> list= new ArrayList<Parent>();
		
		return list;

	}
}
