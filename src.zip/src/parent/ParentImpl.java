package parent;

import connection.HibernateConnection;

import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.hibernate.*;


public class ParentImpl
{
	static  Properties props = new Properties();
	static{
		
		
	        props.put("mail.smtp.auth", "true");
	        props.put("mail.smtp.host", "smtp.gmail.com");
	        props.put("mail.smtp.port", "465");
	        props.put("mail.transport.protocol", "smtp");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

	}
    public ParentImpl()
    {
    }

    public int login(Parent parent) {
    	int login=0;
    	Session sess = HibernateConnection.getSessionFactory().openSession();
        Query query = sess.createQuery("from Parent where  email='"+parent.getEmail()+"' and password='"+parent.getPassword()+"' ");
        List<Parent> list=query.list();
        if(list.size()>0) {
        	login=1;
        	System.out.print("success");
        }
        sess.close();
    	return login;
    }
    
    public int addParent(Parent pb)
    {int ad=0;
    Session sess = HibernateConnection.getSessionFactory().openSession();
         Query query = sess.createQuery("from Parent where  email='"+pb.getEmail()+"' ");
         List<Parent> list=query.list();
         if(list.size()>0) {
         	ad=1;
         	System.out.print("success");
         } 
         if(ad==0) {
         sess.save(pb);
        sess.beginTransaction().commit();
        System.out.println("Parent Added Succesfully : "+pb.getpName());
        }
         
        sess.close();
        try{int p=0;
		try {
		URL url=new URL("http://google.co.in");
		URLConnection conn=url.openConnection();
		conn.connect();
		}catch(Exception e) {p=1;
		System.out.println("No Internet Connection");}
		if(p==0) {
		String from="infinobell@gmail.com",password="Extreme444@";
		System.out.println( from+"    	 "+password );
		javax.mail.Session session = javax.mail.Session.getDefaultInstance(props,
				new javax.mail.Authenticator() {
				protected PasswordAuthentication
				getPasswordAuthentication() {
				return new
				PasswordAuthentication(from , password);
				}});
				Message message = new MimeMessage(session);
				String body="Welcome "+pb.getpName()+"<br>We are happy to see you at Infinobell.<br>Please Click Below link to verify your profile. to Login";
				String f="<form action='http://infinobell.com/student?sub=verify&email="+pb.getEmail()+"&password="+pb.getPassword()+"'></form>";
				message.setFrom (new InternetAddress(from ));
				message.setRecipients(Message.RecipientType.TO,
				InternetAddress.parse(pb.getEmail()));
				message.setSubject("Congratulations -"+pb.getpName()+" Welcome to Vaccination Portal");
				message.setContent(body,"text/html");
				Transport.send(message);
				  
				System.out.println("Email too "+pb.getEmail()+"  is Sent by  "+from+" . ");
		}  
	}catch(Exception e) {}
        
        
        
   return ad;
    }

    public List listParent(String email)
    {
        List list = new ArrayList();
        Session sess = HibernateConnection.getSessionFactory().openSession();
        Query query = sess.createQuery("from Parent where email='"+email+"'");
        list = query.list();
        sess.close();
        return list;
    }

    public void deleteParent(int email)
    {
        Session sess = HibernateConnection.getSessionFactory().openSession();
        Transaction t = sess.beginTransaction();
        Parent parent = (Parent)sess.load(Parent.class, Integer.valueOf(email));
        sess.delete(parent);
        t.commit();
        System.out.println("Deleted");
        sess.close();
    }

   

	public int updateParent(Parent pb) {
		int ad=0;
	    Session sess = HibernateConnection.getSessionFactory().openSession();
	         Parent p = (Parent)sess.load(Parent.class, pb.getId());
	       
	         sess.update(pb);
	        
	        sess.beginTransaction().commit();
	        System.out.println("Parent Updated Succesfully : "+pb.getpName());
	        
	         
	        sess.close();
	   return ad;
	}
}
