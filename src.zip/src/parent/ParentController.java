package parent;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

// Referenced classes of package parent:
//            ParentImpl, ParentBean
@WebServlet("/parent")
public class ParentController extends HttpServlet
{

    ParentImpl pi= new ParentImpl();
    Parent pb=new Parent();

   
    public void doPost(HttpServletRequest req, HttpServletResponse res)
        throws IOException, ServletException
    {
    	doGet(req, res);
    }

    public void doGet(HttpServletRequest req, HttpServletResponse res)
        throws IOException, ServletException
    {
       HttpSession session = req.getSession();
        
        String t = req.getParameter("t");
        String email = req.getParameter("email");
        String mobile = req.getParameter("mobile");
        String city = req.getParameter("city");
        String pName = req.getParameter("pName");
        String mName = req.getParameter("mName");
        String address = req.getParameter("address");
        String pincode = req.getParameter("pincode");
        String password = req.getParameter("password");
        String cname = req.getParameter("cname");
        String state = req.getParameter("state");
        String day = req.getParameter("day");
        String id = req.getParameter("id");
        String month= req.getParameter("month");
        String year = req.getParameter("year");
        SimpleDateFormat sf = new SimpleDateFormat("dd/MM/yyyy");
       String dob=day+"/"+month+"/"+year;
        Date d = new Date();
        String dat = sf.format(d);
        
        
        if(t != null)
        {
        	if(t.equals("viewCertificate"))
            {List<Parent> l=pi.listParent(email);
       	 		req.setAttribute("l", l);
       	 	 RequestDispatcher rd = req.getRequestDispatcher("UploadCertificate.jsp");
             rd.forward(req, res);
        	 }
        		if(t.equals("addParent"))
                {
                    try
                {pb.setDay(Integer.parseInt(day));
                pb.setMonth(Integer.parseInt(month));
                pb.setYear(Integer.parseInt(year));
                Parent par=new Parent(pb.getDay(), pb.getMonth(), pb.getYear(), cname, password, pName, mName, mobile, email, address, city, pincode, dat, state, dob);
                
                  int a= pi.addParent(par);
                  if(a==0) {
                      System.out.println("Parent added from Controller ");
                      RequestDispatcher rd = req.getRequestDispatcher("AddParent.jsp?fid=2");
                      rd.forward(req, res);
                    }
                  if(a==1) {
                      System.out.println("Email Already Exist ");
                      RequestDispatcher rd = req.getRequestDispatcher("AddParent.jsp?fid=4");
                      rd.forward(req, res);
                    }
                  
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }
            }
        	if(t.equals("updateParent"))
            {
                try
                {pb.setId(Integer.parseInt(id));
                pb.setDay(Integer.parseInt(day));
                pb.setMonth(Integer.parseInt(month));
                pb.setYear(Integer.parseInt(year));
                Parent pp=new Parent(pb.getId(), pb.getDay(), pb.getMonth(), pb.getYear(), cname, pName, mName, mobile, address, city, pincode, state, dob);
                  int a= pi.updateParent(pp);
                  if(a==0) {
                      System.out.println("Parent Updated ");
                      List<Parent> l=pi.listParent(email);
                 	 for(Parent par: l) {
                 		 session.setAttribute("pname",par.getpName());
                 		 session.setAttribute("cname",par.getcName());
                  		 session.setAttribute("pid",par.getId());
                      	 System.out.println(par.getId());
                      session.setAttribute("mac", "Parent");
                      session.setAttribute("email", email);
                      ServletContext context=req.getServletContext();
                      context.setAttribute("list", l);
                     
                      RequestDispatcher rd = req.getRequestDispatcher("EditParent.jsp?fid=2");
                      rd.forward(req, res);
                    }
                 	 }
                  else {
                      System.out.println("Not Updated ");
                      RequestDispatcher rd = req.getRequestDispatcher("EditParent.jsp?fid=4");
                      rd.forward(req, res);
                    }
                  
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }
            }
        	 
        	 if(t.equals("login"))
             {
                 try
                 {
                	 Parent p=new Parent(password, email);
                     int login=pi.login(p);
                     if(login==1) {
                    	 List<Parent> l=pi.listParent(email);
                    	 for(Parent par: l) {
                    		 session.setAttribute("pname",par.getpName());
                    		 session.setAttribute("cname",par.getcName());
                     		 session.setAttribute("pid",par.getId());
                         	 System.out.println(par.getId());
                         session.setAttribute("mac", "Parent");
                         session.setAttribute("email", email);
                    	 }
                         RequestDispatcher rd = req.getRequestDispatcher("parent?t=viewpar");
                         rd.forward(req, res);
                         }
                     if(login==0) {
                         RequestDispatcher rd = req.getRequestDispatcher("index.jsp");
                         rd.forward(req, res);
                         }
                 }
                 catch(Exception e)
                 {
                     e.printStackTrace();
                 }
             }
            if(t.equals("viewpar"))
            {
                java.util.List list = new ArrayList();
                list = pi.listParent((String)session.getAttribute("email"));
                
                ServletContext context=req.getServletContext();
                context.setAttribute("list", list);
                RequestDispatcher rd1 = req.getRequestDispatcher("ViewParent.jsp");
                rd1.forward(req, res);
            }
        }
    }
}
