package parent;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Parent")
public class Parent
{
@Id @GeneratedValue(strategy=GenerationType.AUTO)
    private int id;
    private int day;
    private int month;
    private int year;
    private String cName;
    private String password;
	private String pName;
    private String mName;
    private String mobile;
    private String email;
    private String address;
    private String age;
    private String verify;
    private String city;
    private String pincode;
    private String dateadded;
    private String state;
    private String dob,fileFileName;

    public Parent(int id, int day, int month, int year, String cName, String pName, String mName, String mobile,
			String address,  String city, String pincode, String state, String dob) {
		super();
		this.id = id;
		this.day = day;
		this.month = month;
		this.year = year;
		this.cName = cName;
		this.pName = pName;
		this.mName = mName;
		this.mobile = mobile;
		this.address = address;
		this.city = city;
		this.pincode = pincode;
		this.state = state;
		this.dob = dob;
	}
    
	public Parent(String password, String email) {
		super();
		this.password = password;
		this.email = email;
	}

	public Parent(int day, int month, int year, String cName, String password, String pName, String mName,
			String mobile, String email, String address, String city, String pincode, String dateadded, String state,
			String dob) {
		super();
		this.day = day;
		this.month = month;
		this.year = year;
		this.cName = cName;
		this.password = password;
		this.pName = pName;
		this.mName = mName;
		this.mobile = mobile;
		this.email = email;
		this.address = address;
		this.city = city;
		this.pincode = pincode;
		this.dateadded = dateadded;
		this.state = state;
		this.dob = dob;
	}

	public Parent()
    {
    }

    public int getId()
    {
        return id;
    }

    public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

    public int getDay()
    {
        return day;
    }

    public void setDay(int day)
    {
        this.day = day;
    }

    public int getMonth()
    {
        return month;
    }

    public void setMonth(int month)
    {
        this.month = month;
    }

    public int getYear()
    {
        return year;
    }

    public void setYear(int year)
    {
        this.year = year;
    }

    public String getDateadded()
    {
        return dateadded;
    }

    public String getState()
    {
        return state;
    }

    public void setState(String state)
    {
        this.state = state;
    }

    public void setDateadded(String dateadded)
    {
        this.dateadded = dateadded;
    }

    public String getCity()
    {
        return city;
    }

    public void setCity(String city)
    {
        this.city = city;
    }

    public String getPincode()
    {
        return pincode;
    }

    public void setPincode(String pincode)
    {
        this.pincode = pincode;
    }

    public void setAddress(String address)
    {
        this.address = address;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getcName()
    {
        return cName;
    }

    public void setcName(String cName)
    {
        this.cName = cName;
    }

    public String getpName()
    {
        return pName;
    }

    public void setpName(String pName)
    {
        this.pName = pName;
    }

    public String getmName()
    {
        return mName;
    }

    public void setmName(String mName)
    {
        this.mName = mName;
    }

    public String getMobile()
    {
        return mobile;
    }

    public void setMobile(String mobile)
    {
        this.mobile = mobile;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getAddress()
    {
        return address;
    }

    public void setAdress(String adress)
    {
        address = adress;
    }

    public String getDob()
    {
        return dob;
    }

    public void setDob(String dob)
    {
        this.dob = dob;
    }

    public String getAge()
    {
        return age;
    }

    public String getFileFileName() {
		return fileFileName;
	}

	public void setFileFileName(String fileFileName) {
		this.fileFileName = fileFileName;
	}

	public void setAge(String age)
    {
        this.age = age;
    }

    public String getVerify()
    {
        return verify;
    }

    public void setVerify(String verify)
    {
        this.verify = verify;
    }
}
