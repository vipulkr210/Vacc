package parent;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;

import com.opensymphony.xwork2.ActionSupport;

import connection.HibernateConnection;

public class UploadCertificate extends ActionSupport{
	private int id;
	 private File file;
	    private String filecontenttype;
	    private String fileFileName,username,email;
	    private String filePathToSaveInDB;

		public int getId() {
			System.out.print(id);
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		
public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

public File getFile() {
			return file;
		}

		public void setFile(File file) {
			this.file = file;
		}

		public String getFilecontenttype() {
			return filecontenttype;
		}

		public void setFilecontenttype(String filecontenttype) {
			this.filecontenttype = filecontenttype;
		}

		public String getFileFileName() {
			return fileFileName;
		}

		public void setFileFileName(String fileFileName) {
			this.fileFileName = fileFileName;
		}

		public String getUsername() {
			 System.out.println("pic uploaded "+ username+"  hii");
		       
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public String getFilePathToSaveInDB() {
			return filePathToSaveInDB;
		}

		public void setFilePathToSaveInDB(String filePathToSaveInDB) {
			this.filePathToSaveInDB = filePathToSaveInDB;
		}
	    
	    

 
	    public String execute() throws Exception {
			try
	        {
		
				ServletContext servletContext = ServletActionContext.getServletContext();
	            String path = "Files/"+id+"/";
	            String filePath = servletContext.getRealPath(path);
	           File uploadDir = new File(filePath);
	            if(!uploadDir.exists())
	            {
	                uploadDir.mkdirs();
	            }
	           FileUtils.copyFile(file, new File(uploadDir, fileFileName));
	           
	           Session sess=HibernateConnection.getSessionFactory().openSession();
	           Parent po=(Parent)sess.load(Parent.class, id);
	   	     //String fg=ou.format(dat;
	           po.setFileFileName(fileFileName);
	    		 sess.update(po);
	           sess.beginTransaction().commit();
	             System.out.println("pic uploaded "+ fileFileName);
	            sess.close();
	            ParentImpl p=new ParentImpl();
	            List l=p.listParent(email);
	            servletContext.setAttribute("l",l);
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	        }
			
			
			return SUCCESS;
		}
}
