package email;

import java.net.URL;
import java.net.URLConnection;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailNow {

	static  Properties props = new Properties();
	static{
		
		
	        props.put("mail.smtp.auth", "true");
	        props.put("mail.smtp.host", "smtp.gmail.com");
	        props.put("mail.smtp.port", "465");
	        props.put("mail.transport.protocol", "smtp");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

	}
	
	public void sendMail(String to,String body,String subj){
		
			try{int p=0;
	  		try {
	  		URL url=new URL("http://google.co.in");
	  		URLConnection conn=url.openConnection();
	  		conn.connect();
	  		}catch(Exception e) {p=1;
	  		System.out.println("No Internet Connection");}
	  		
		String from="infinobell@gmail.com",password="Extreme444@";
		
		Session s=Session.getDefaultInstance(props, new Authenticator() {
			protected PasswordAuthentication getPasswordAuth() {
				System.out.println("Password: "+password);
				return new PasswordAuthentication(from, password);
			}
		});
		Message message = new MimeMessage(s);
		message.setFrom (new InternetAddress(from ));
		message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(to));
		message.setSubject(subj);
		message.setContent(body,"text/html");
		Transport.send(message);
	  		
			}	
		catch (Exception e) {
			e.printStackTrace();
		}
		}
}
/*
	try{int p=0;
		try {
		URL url=new URL("http://google.co.in");
		URLConnection conn=url.openConnection();
		conn.connect();
		}catch(Exception e) {p=1;
		System.out.println("No Internet Connection");}
		if(p==0) {
		String from="infinobell@gmail.com",password="Extreme444@";
		javax.mail.Session session = javax.mail.Session.getDefaultInstance(props,
				new javax.mail.Authenticator() {
				protected PasswordAuthentication
				getPasswordAuthentication() {
				return new
				PasswordAuthentication(from , password);
				}});
				Message message = new MimeMessage(session);
				
				message.setFrom (new InternetAddress(from ));
				message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(email));
				message.setSubject(subj);
				message.setContent(body,"text/html");
				Transport.send(message);
				  
		}  
	}catch(Exception e) {}
    
*/	

