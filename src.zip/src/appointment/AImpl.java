package appointment;

import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.hibernate.Query;
import org.hibernate.Session;

import connection.HibernateConnection;
import email.EmailNow;

public class AImpl{
	static  Properties props = new Properties();
	static{
		
		
	        props.put("mail.smtp.auth", "true");
	        props.put("mail.smtp.host", "smtp.gmail.com");
	        props.put("mail.smtp.port", "465");
	        props.put("mail.transport.protocol", "smtp");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

	}

	
	public List<Appointment> listPatient(String did) {
		
		List<Appointment> list= new ArrayList<Appointment>();
		Session sess=HibernateConnection.getSessionFactory().openSession();
		Query query=sess.createQuery("from Appointment where did='"+did+"'");
		list=query.list();
		sess.close();
		

			
			return list;
	}

	public void cancelAppointment(int id){
		Session sess=HibernateConnection.getSessionFactory().openSession();
		
		Appointment at=	(Appointment)sess.load(Appointment.class,id);
		sess.delete(at);
		
		
		sess.beginTransaction().commit();
		sess.close();
	}
	
	public List<Appointment> parentRecord(String pid) {
		
		List<Appointment> list= new ArrayList<Appointment>();
		Session sess=HibernateConnection.getSessionFactory().openSession();
	Query query=sess.createQuery("from Appointment where pid='"+pid+"'");
	list=query.list();
	sess.close();
	

		
		return list;
   
	}

	public List<Appointment> listAppointmentbyDate(String adate) {
		List<Appointment> list= new ArrayList<Appointment>();
		Session sess=HibernateConnection.getSessionFactory().openSession();
	Query query=sess.createQuery("from Appointment where adate='"+adate+"'  ");
	list=query.list();
	sess.close();
	

		
		return list;
	}

	public void actionAppointment(int id, String status,String adate,String email) {
Session sess=HibernateConnection.getSessionFactory().openSession();
		
		Appointment at=	(Appointment)sess.load(Appointment.class,id);
		at.setAccept(Integer.parseInt(status));
		sess.update(at);
		
		
		
		sess.beginTransaction().commit();
		
		
		String subj="";String body="";
			if(status.equals("1")) {subj="Your Appointment is fixed for "+adate;
			body="Please reach on time on "+adate;}
			if(status.equals("2")) {subj="Your Appointment Has Been Rejected for Date: "+adate;
			body="Apply Again For the Same .<br> Thank you.";
			}
  		EmailNow en=new EmailNow();
  		en.sendMail(email, body, subj);
  		System.out.println("Email too "+email+"  is Sent ");
  		
		
		
		
		sess.close();	
	}

	public void addAppointment(Appointment app) {
		Session s=HibernateConnection.getSessionFactory().openSession();
		s.save(app);
		s.beginTransaction().commit();
		s.close();
	}}
