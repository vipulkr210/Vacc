package appointment;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Appointment")
public class Appointment {
	@Id @GeneratedValue(strategy=GenerationType.AUTO)
	private int id;

	@Column(columnDefinition="int default 0")
	private int accept;
	String did,pid,pname,dname,adate,cname,city,description,age,mobile,email;
	
	public Appointment() {
		// TODO Auto-generated constructor stub
	}
	public Appointment(String did, String pid, String pname, String dname, String adate, String cname, String city,
			String description, String age, String mobile, String email) {
		super();
		this.did = did;
		this.pid = pid;
		this.pname = pname;
		this.dname = dname;
		this.adate = adate;
		this.cname = cname;
		this.city = city;
		this.description = description;
		this.age = age;
		this.mobile = mobile;
		this.email = email;
	}
	public int getId() {
		return id;
	}
	public int getAccept() {
		return accept;
	}
	@Column(columnDefinition="int default 0")
	public void setAccept(int accept) {
		this.accept = accept;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDid() {
		return did;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public void setDid(String did) {
		this.did = did;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getAdate() {
		return adate;
	}
	public void setAdate(String adate) {
		this.adate = adate;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	

}
