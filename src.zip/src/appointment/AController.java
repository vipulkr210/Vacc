package appointment;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.Transaction;

import connection.HibernateConnection;
import doctor.Doctor;
import doctor.DoctorImpl;

/**
 * Servlet implementation class AController
 */
@WebServlet("/AController")
public class AController extends HttpServlet {
	private static final long serialVersionUID = 1L;
     Appointment a=new Appointment();  
     AImpl ai=new AImpl();
     	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html");
		
		String accept=request.getParameter("accept");
		String id=request.getParameter("id");
		String did=request.getParameter("did");
		String dname=request.getParameter("dname");
		String mobile=request.getParameter("mobile");
		String city=request.getParameter("city");
		String description=request.getParameter("description");

		String age=request.getParameter("age");	
		String email=request.getParameter("email");	
		String adate=request.getParameter("adate");
		String cname=request.getParameter("cname");
		String pname=request.getParameter("pname");
		String pid=request.getParameter("pid");
		String t=request.getParameter("t");
		String status=request.getParameter("status");
		
		if(t!=null){
			if(t.equals("takeappointment")){
			Appointment app= new Appointment(did, pid, pname, dname, adate, cname, city, description, age, mobile, email);
			ai.addAppointment(app);
			
		System.out.println("Appoint Fixed : "+adate);
			
			
		
				RequestDispatcher rd=request.getRequestDispatcher("ParentAppointment.jsp?fid=2");rd.forward(request, response);
				
		
			}
			 if(t.equals("viewPatient")){
					
			    	List<Appointment> list = new ArrayList<>();
					
			    		list = ai.listPatient(dname);
					            request.setAttribute("listPatients", list);
					            
					            RequestDispatcher rd1 = request.getRequestDispatcher("DoctorAppointment.jsp");
					            rd1.forward(request,response);
					    	
						}
			 
			 if(t.equals("viewappointmentbydate")){
					
			    	List<Appointment> list = new ArrayList<>();
					
			    		list = ai.listAppointmentbyDate(adate);
					            request.setAttribute("appointmentlist", list);
					            
					            RequestDispatcher rd1 = request.getRequestDispatcher("TodayAppointment.jsp");
					            rd1.forward(request,response);
					    	
						}
       if(t.equals("precord")){
			
       	List<Appointment> list = new ArrayList<>();
   		
       		list = ai.parentRecord(pid);
   		            request.setAttribute("listparentapp", list);
   		            
   		            RequestDispatcher rd1 = request.getRequestDispatcher("ParentRecord.jsp");
   		            rd1.forward(request,response);
   		    	
   			}
   	if(t.equals("cancelappointment")){
   		System.out.println("IN : ");
		ai.cancelAppointment(Integer.parseInt(id));
   		System.out.println("OUT  : ");
		
        RequestDispatcher rd1 = request.getRequestDispatcher("ParentRecord.jsp");
           rd1.forward(request,response);

   	}
	if(t.equals("appointment")){
		String pemail=request.getParameter("pemail");
   		ai.actionAppointment(Integer.parseInt(id), status,adate,pemail);
   		
        RequestDispatcher rd1 = request.getRequestDispatcher("AController?t=viewappointmentbydate&adate="+adate);
           rd1.forward(request,response);

   	}
   if(t.equals("viewans")){
	   
	   Session sess=HibernateConnection.getSessionFactory().openSession();
		
		Transaction ty=sess.beginTransaction();
		Appointment at=	(Appointment)sess.load(Appointment.class,Integer.parseInt(id));
		at.setAccept(Integer.parseInt(accept));
		sess.update(at);
		
		
		ty.commit();
		sess.close();

           RequestDispatcher rd1 = request.getRequestDispatcher("ParentRecord.jsp");
           rd1.forward(request,response);
	   
   }
		}
		
	}

     	@Override
     	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
     		// TODO Auto-generated method stub
     		doPost(req, resp);
     	}
}
