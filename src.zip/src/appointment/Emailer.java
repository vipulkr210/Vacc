package appointment;

import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.servlet.ServletRequest;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import connection.JDBCConnection;


@Entity
@Table(name="emailsend")
public class Emailer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private	String	from;
	private	String	 password	;
	private	String	 to;
	private	String	 subject	;
	private	String	 body;
	 private String data;
	static  Properties props = new Properties();
	static{
		
		
	        props.put("mail.smtp.auth", "true");
	        props.put("mail.smtp.host", "smtp.gmail.com");
	        props.put("mail.smtp.port", "465");
	        props.put("mail.transport.protocol", "smtp");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

	}
	
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String execute(){
		String ret = "";
		try{
			System.out.println(from +"    	 "+password );
			Session session = Session.getDefaultInstance(props,
					new javax.mail.Authenticator() {
					protected PasswordAuthentication
					getPasswordAuthentication() {
					return new
					PasswordAuthentication(from , password);
					}});
					Message message = new MimeMessage(session);
					message.setFrom (new InternetAddress(from ));
					message.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(to));
					message.setSubject(subject);
					message.setContent(body,"text/html");
					Transport.send(message);
				  
					System.out.println("Email too "+to+"  is Sent by  "+from+" . ");
					
					JDBCConnection mc = new JDBCConnection();
					 mc.connect();
					 Statement st=mc.con.createStatement();
					 String mb="";
					 ResultSet l= st.executeQuery("select mobile from staff  where id='"+id+"'");
         			while(l.next()){
         				mb=l.getString(1);
         				
         			}
         			
								    			st.executeUpdate("update staff set verify=1,password='"+mb+"'  where id='"+id+"'");
					                			System.out.println("Faculty Verified  "+id);
						
					mc.con.close();
					 
				        	AnnotationConfiguration cfg = new AnnotationConfiguration();
				        	SessionFactory factory = cfg.configure().buildSessionFactory();
				        	org.hibernate.Session session2 = factory.openSession();
				        	Transaction transaction = session2.beginTransaction();
				       Emailer ee=new Emailer();
				     
				       DateFormat fff = new SimpleDateFormat("dd/MMM/yyyy");
			            data = fff.format(new Date());
			           ee.setBody(body);
				       ee.setFrom(from);
				       ee.setTo(to);
				       ee.setSubject(subject);
				       ee.setData(data);
				       
				       session2.save(ee);
			            transaction.commit();
			            System.out.println("Email also saved in database  "+to);
			            
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return ret;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public static Properties getProps() {
		return props;
	}
	public static void setProps(Properties props) {
		Emailer.props = props;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public static Properties getProperties() {
		return props;
	}
	public static void setProperties(Properties properties) {
		Emailer.props = properties;
	}
	
	
}
