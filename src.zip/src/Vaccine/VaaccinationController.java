package Vaccine;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import parent.Parent;
import parent.ParentImpl;
@WebServlet("/vaccine")
public class VaaccinationController extends HttpServlet{
	VaccineChart vchart =new VaccineChart();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String dBCG=req.getParameter("dBCG"),dOPV0=req.getParameter("dOPV0"),dHepB1=req.getParameter("dHepB1"),dDTwP1=req.getParameter("dDTwP1"),dIPV1=req.getParameter("dIPV1")
		,dHepB2=req.getParameter("dHepB2"),dRotavirus1=req.getParameter("dRotavirus1"),dPCV2=req.getParameter("dPCV2"),dDTwP2=req.getParameter("dDTwP2"),dIPV2=req.getParameter("dIPV2")
		,dHibB1=req.getParameter("dHibB1"),dRva=req.getParameter("dRva"),dDTwP3=req.getParameter("dDTwP3"),dIPV3=req.getParameter("dIPV3"),dHib3=req.getParameter("dHib3")
		,dRotavirus3=req.getParameter("dRotavirus3"),dPCV3=req.getParameter("dPCV3"),dOPV1=req.getParameter("dOPV1"),dHepB3=req.getParameter("dHepB3"),dOPV2=req.getParameter("dOPV2")
		,dMMR1=req.getParameter("dMMR1"),dTyphoidConjugate=req.getParameter("dTyphoidConjugate"),dHepA1=req.getParameter("dHepA1"),dMMR2=req.getParameter("dMMR2")
		,dVaricella1=req.getParameter("dVaricella1"),dPCVBooster=req.getParameter("dPCVBooster"),dDTwPB1DTapB1=req.getParameter("dDTwPB1DTapB1"),dIPVB1=req.getParameter("dIPVB1")
		,dHepA2=req.getParameter("dHepA2"),dTyphoidBooster1=req.getParameter("dTyphoidBooster1"),dDTwPB2DTapB2=req.getParameter("dDTwPB2DTapB2"),dOPV3=req.getParameter("dOPV3")
		,dVericella2=req.getParameter("dVericella2"),dTyphoidBooster2=req.getParameter("dTyphoidBooster2"),dTdapTd=req.getParameter("dTdapTd"),
		dHPV1=req.getParameter("dHPV1"),dHPV2=req.getParameter("dHPV2"),dHDHIP=req.getParameter("dHDHIP"),dHIBB11=req.getParameter(""),dPCV22=req.getParameter("dPCV22");
		
		String BCG=req.getParameter("BCG"),OPV0=req.getParameter("OPV0"),HepB1=req.getParameter("HepB1"),DTwP1=req.getParameter("DTwP1"),
			IPV1=req.getParameter("IPV1"),HepB2=req.getParameter("HepB2"),Rotavirus1=req.getParameter("Rotavirus1"),PCV2=req.getParameter("PCV2"),
			DTwP2=req.getParameter("DTwP2"),IPV2=req.getParameter("IPV2"),HibB1=req.getParameter("HibB1"),Rotavirus2=req.getParameter("Rotavirus2"),
			DTwP3=req.getParameter("DTwP3"),IPV3=req.getParameter("IPV3"),Hib3=req.getParameter("Hib3"),Rotavirus3=req.getParameter("Rotavirus3"),
			PCV3=req.getParameter("PCV3"),OPV1=req.getParameter("OPV1"),HepB3=req.getParameter("HepB3"),OPV2=req.getParameter("OPV2"),
			MMR1=req.getParameter("MMR1"),TyphoidConjugate=req.getParameter("TyphoidConjugate"),HepA1=req.getParameter("HepA1"),
			MMR2=req.getParameter("MMR2"),Varicella1=req.getParameter("Varicella1"),PCVBooster=req.getParameter("PCVBooster"),
			DTwPB1DTapB1=req.getParameter("DTwPB1DTapB1"),IPVB1=req.getParameter("IPVB1"),HepA2=req.getParameter("HepA2"),
			TyphoidBooster1=req.getParameter("TyphoidBooster1"),DTwPB2DTapB2=req.getParameter("DTwPB2DTapB2"),OPV3=req.getParameter("OPV3"),
			Vericella2=req.getParameter("Vericella2"),TyphoidBooster2=req.getParameter("TyphoidBooster2"),TdapTd=req.getParameter("TdapTd"),
			HPV1=req.getParameter("HPV1"),HPV2=req.getParameter("HPV2"),HDHIP=req.getParameter("HDHIP"),HIBB1=req.getParameter("HIBB1"),PCV22=req.getParameter("PCV22");
	String t=req.getParameter("t");
	HttpSession s=req.getSession();
	String id1=req.getParameter("pid");
	String email=(String)s.getAttribute("email");
	String pid=req.getParameter("pid"), cname=req.getParameter("cname"), dob=req.getParameter("dob"), day=req.getParameter("day"), month=req.getParameter("month"), year=req.getParameter("year"), fileFileName=req.getParameter("fileFileName"), data;
	SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
	data=sdf.format(new Date());
	if(t!=null) {
		if(t.equals("filldate")) {
			VaccineChart v= new VaccineChart(BCG, OPV0, HepB1, DTwP1, IPV1, HepB2, Rotavirus1, PCV2, DTwP2, IPV2, HibB1, Rotavirus2, DTwP3, IPV3, Hib3, Rotavirus3, PCV3, OPV1, HepB3, OPV2, MMR1, TyphoidConjugate, HepA1, MMR2, Varicella1, PCVBooster, DTwPB1DTapB1, IPVB1, HepA2, TyphoidBooster1, DTwPB2DTapB2, OPV3, Vericella2, TyphoidBooster2, TdapTd, HPV1, HPV2, pid, cname, dob, day, month, year, fileFileName, data,HDHIP,HIBB1,PCV22,dBCG, dOPV0, dHepB1, dDTwP1, dIPV1, dHepB2, dRotavirus1, dPCV2, dDTwP2, dIPV2, dHibB1, dRva, dDTwP3, dIPV3, dHib3, dRotavirus3, dPCV3, dOPV1, dHepB3, dOPV2, dMMR1, dTyphoidConjugate, dHepA1, dMMR2, dVaricella1, dPCVBooster, dDTwPB1DTapB1, dIPVB1, dHepA2, dTyphoidBooster1, dDTwPB2DTapB2, dOPV3, dVericella2, dTyphoidBooster2, dTdapTd, dHPV1, dHPV2, dHDHIP, dHIBB11, dPCV22);
			VaccinationImpl vi=new VaccinationImpl();
			int vvv=vi.addVChart(v);
			System.out.println("Added Succesfully");
			
			if(vvv>0) {
				
				VaccineChart vt= new  VaccineChart(dBCG, dOPV0, dHepB1, dDTwP1, dIPV1, dHepB2, dRotavirus1, dPCV2, dDTwP2, dIPV2, dHibB1, dRva, dDTwP3, dIPV3, dHib3, dRotavirus3, dPCV3, dOPV1, dHepB3, dOPV2, dMMR1, dTyphoidConjugate, dHepA1, dMMR2, dVaricella1, dPCVBooster, dDTwPB1DTapB1, dIPVB1, dHepA2, dTyphoidBooster1, dDTwPB2DTapB2, dOPV3, dVericella2, dTyphoidBooster2, dTdapTd, dHPV1, dHPV2, dHDHIP, dHIBB11, dPCV22);
				
				vi.editVaccine(v, vvv);
				System.out.println("Updated Succesfully");
				
			}
			List<VaccineChart> li=vi.viewChart(id1);
			ParentImpl pi=new ParentImpl();
			List<Parent> li1=pi.listParent(email);
			req.setAttribute("chart", li);
			req.setAttribute("s", li1);
			RequestDispatcher rd=req.getRequestDispatcher("Vchart.jsp?t=viewed");
			rd.forward(req, resp);
		}
		
		if(t.equals("view")) {
			VaccinationImpl vi=new VaccinationImpl();
			System.out.println("1 "+pid);
			
			List<VaccineChart> li=vi.viewChart(pid);
			ServletContext cc=getServletContext();
			
			ParentImpl pi=new ParentImpl();
			List<Parent> li1=pi.listParent(email);
			req.setAttribute("chart", li);
			for(VaccineChart vv:li) {
				System.out.println("1 "+vv.getRva());
			}
			req.setAttribute("s", li1);
			RequestDispatcher rd=req.getRequestDispatcher("Vchart.jsp?t=viewed");
			rd.forward(req, resp);
		}
	}
		
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, resp);
	}
	
}
