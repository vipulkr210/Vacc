package Vaccine;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table(name="VaccineChart")
public class VaccineChart {
	@Id @GeneratedValue(strategy=GenerationType.AUTO)
	private int id; 
	@Column(columnDefinition="varchar(40) default 'na'")
	private String BCG,OPV0,HepB1,DTwP1,IPV1,HepB2,Rotavirus1,PCV2,DTwP2,IPV2,HibB1,Rva,DTwP3,IPV3,Hib3,Rotavirus3,PCV3,OPV1,HepB3,OPV2,MMR1,TyphoidConjugate,HepA1,MMR2,Varicella1,PCVBooster,DTwPB1DTapB1,IPVB1,HepA2,TyphoidBooster1,DTwPB2DTapB2,OPV3,Vericella2,TyphoidBooster2,TdapTd,HPV1,HPV2,HDHIP,HIBB11,PCV22;
	@Column(columnDefinition="varchar(40) default 'na'")
	private String dBCG,dOPV0,dHepB1,dDTwP1,dIPV1,dHepB2,dRotavirus1,dPCV2,dDTwP2,dIPV2,dHibB1,dRva,dDTwP3,dIPV3,dHib3,dRotavirus3,dPCV3,dOPV1,dHepB3,dOPV2,dMMR1,dTyphoidConjugate,dHepA1,dMMR2,dVaricella1,dPCVBooster,dDTwPB1DTapB1,dIPVB1,dHepA2,dTyphoidBooster1,dDTwPB2DTapB2,dOPV3,dVericella2,dTyphoidBooster2,dTdapTd,dHPV1,dHPV2,dHDHIP,dHIBB11,dPCV22;
	
	private String pid,cname,dob,day,month,year,fileFileName,data;
	
	public VaccineChart() {
		// TODO Auto-generated constructor stub
	}
	public VaccineChart(String BCG, String OPV0, String HepB1, String DTwP1, String IPV1, String HepB2,
			String Rotavirus1, String PCV2, String DTwP2, String IPV2, String HibB1, String Rva, String DTwP3,
			String IPV3, String Hib3, String Rotavirus3, String PCV3, String OPV1, String HepB3, String OPV2,
			String MMR1, String TyphoidConjugate, String HepA1, String MMR2, String Varicella1, String PCVBooster,
			String DTwPB1DTapB1, String IPVB1, String HepA2, String TyphoidBooster1, String DTwPB2DTapB2, String OPV3,
			String Vericella2, String TyphoidBooster2, String TdapTd, String HPV1, String HPV2, String pid,
			String cname, String dob, String day, String month, String year, String fileFileName, String data,String HDHIP,String HIBB11,
			String PCV22,String dBCG, String dOPV0, String dHepB1, String dDTwP1, String dIPV1, String dHepB2,
			String dRotavirus1, String dPCV2, String dDTwP2, String dIPV2, String dHibB1, String dRva, String dDTwP3,
			String dIPV3, String dHib3, String dRotavirus3, String dPCV3, String dOPV1, String dHepB3, String dOPV2,
			String dMMR1, String dTyphoidConjugate, String dHepA1, String dMMR2, String dVaricella1, String dPCVBooster,
			String dDTwPB1DTapB1, String dIPVB1, String dHepA2, String dTyphoidBooster1, String dDTwPB2DTapB2,
			String dOPV3, String dVericella2, String dTyphoidBooster2, String dTdapTd, String dHPV1, String dHPV2,
			String dHDHIP, String dHIBB11, String dPCV22) {
		super();

		this.BCG = BCG;		this.OPV0 = OPV0;this.HDHIP=HDHIP;this.HIBB11=HIBB11;this.PCV22=PCV22;
		this.HepB1 = HepB1;		this.DTwP1 = DTwP1;		this.IPV1 = IPV1;		this.HepB2 = HepB2;		this.Rotavirus1 = Rotavirus1;
		PCV2 = PCV2;		this.DTwP2 = DTwP2;		this.IPV2 = IPV2;		this.HibB1 = HibB1;		this.Rva = Rva;		this.DTwP3 = DTwP3;		this.IPV3 = IPV3;		Hib3 = Hib3;		Rotavirus3 = Rotavirus3;		PCV3 = PCV3;		OPV1 = OPV1;		HepB3 = HepB3;		OPV2 = OPV2;
		this.MMR1 = MMR1;		this.TyphoidConjugate = TyphoidConjugate;		this.HepA1 = HepA1;		this.MMR2 = MMR2;		
		this.Varicella1 = Varicella1;		this.PCVBooster = PCVBooster;		this.DTwPB1DTapB1 = DTwPB1DTapB1;		this.IPVB1 = IPVB1;
		this.HepA2 = HepA2;
		this.TyphoidBooster1 = TyphoidBooster1;
		this.DTwPB2DTapB2 = DTwPB2DTapB2;
		this.OPV3 = OPV3;
		this.Vericella2 = Vericella2;
		this.TyphoidBooster2 = TyphoidBooster2;
		this.TdapTd = TdapTd;
		this.HPV1 = HPV1;
		this.HPV2 = HPV2;
		this.pid = pid;
		this.cname = cname;
		this.dob = dob;
		this.day = day;
		this.month = month;
		this.year = year;
		this.fileFileName = fileFileName;
		this.data = data;
		this.dBCG = dBCG;
		this.dOPV0 = dOPV0;
		this.dHepB1 = dHepB1;
		this.dDTwP1 = dDTwP1;
		this.dIPV1 = dIPV1;
		this.dHepB2 = dHepB2;
		this.dRotavirus1 = dRotavirus1;
		this.dPCV2 = dPCV2;
		this.dDTwP2 = dDTwP2;
		this.dIPV2 = dIPV2;
		this.dHibB1 = dHibB1;
		this.dRva = dRva;
		this.dDTwP3 = dDTwP3;
		this.dIPV3 = dIPV3;
		this.dHib3 = dHib3;
		this.dRotavirus3 = dRotavirus3;
		this.dPCV3 = dPCV3;
		this.dOPV1 = dOPV1;
		this.dHepB3 = dHepB3;
		this.dOPV2 = dOPV2;
		this.dMMR1 = dMMR1;
		this.dTyphoidConjugate = dTyphoidConjugate;
		this.dHepA1 = dHepA1;
		this.dMMR2 = dMMR2;
		this.dVaricella1 = dVaricella1;
		this.dPCVBooster = dPCVBooster;
		this.dDTwPB1DTapB1 = dDTwPB1DTapB1;
		this.dIPVB1 = dIPVB1;
		this.dHepA2 = dHepA2;
		this.dTyphoidBooster1 = dTyphoidBooster1;
		this.dDTwPB2DTapB2 = dDTwPB2DTapB2;
		this.dOPV3 = dOPV3;
		this.dVericella2 = dVericella2;
		this.dTyphoidBooster2 = dTyphoidBooster2;
		this.dTdapTd = dTdapTd;
		this.dHPV1 = dHPV1;
		this.dHPV2 = dHPV2;
		this.dHDHIP = dHDHIP;
		this.dHIBB11 = dHIBB11;
		this.dPCV22 = dPCV22;
	}
	
	public VaccineChart(String dBCG, String dOPV0, String dHepB1, String dDTwP1, String dIPV1, String dHepB2,
			String dRotavirus1, String dPCV2, String dDTwP2, String dIPV2, String dHibB1, String dRva, String dDTwP3,
			String dIPV3, String dHib3, String dRotavirus3, String dPCV3, String dOPV1, String dHepB3, String dOPV2,
			String dMMR1, String dTyphoidConjugate, String dHepA1, String dMMR2, String dVaricella1, String dPCVBooster,
			String dDTwPB1DTapB1, String dIPVB1, String dHepA2, String dTyphoidBooster1, String dDTwPB2DTapB2,
			String dOPV3, String dVericella2, String dTyphoidBooster2, String dTdapTd, String dHPV1, String dHPV2,
			String dHDHIP, String dHIBB11, String dPCV22) {
		super();
		this.dBCG = dBCG;
		this.dOPV0 = dOPV0;
		this.dHepB1 = dHepB1;
		this.dDTwP1 = dDTwP1;
		this.dIPV1 = dIPV1;
		this.dHepB2 = dHepB2;
		this.dRotavirus1 = dRotavirus1;
		this.dPCV2 = dPCV2;
		this.dDTwP2 = dDTwP2;
		this.dIPV2 = dIPV2;
		this.dHibB1 = dHibB1;
		this.dRva = dRva;
		this.dDTwP3 = dDTwP3;
		this.dIPV3 = dIPV3;
		this.dHib3 = dHib3;
		this.dRotavirus3 = dRotavirus3;
		this.dPCV3 = dPCV3;
		this.dOPV1 = dOPV1;
		this.dHepB3 = dHepB3;
		this.dOPV2 = dOPV2;
		this.dMMR1 = dMMR1;
		this.dTyphoidConjugate = dTyphoidConjugate;
		this.dHepA1 = dHepA1;
		this.dMMR2 = dMMR2;
		this.dVaricella1 = dVaricella1;
		this.dPCVBooster = dPCVBooster;
		this.dDTwPB1DTapB1 = dDTwPB1DTapB1;
		this.dIPVB1 = dIPVB1;
		this.dHepA2 = dHepA2;
		this.dTyphoidBooster1 = dTyphoidBooster1;
		this.dDTwPB2DTapB2 = dDTwPB2DTapB2;
		this.dOPV3 = dOPV3;
		this.dVericella2 = dVericella2;
		this.dTyphoidBooster2 = dTyphoidBooster2;
		this.dTdapTd = dTdapTd;
		this.dHPV1 = dHPV1;
		this.dHPV2 = dHPV2;
		this.dHDHIP = dHDHIP;
		this.dHIBB11 = dHIBB11;
		this.dPCV22 = dPCV22;
	}
	public String getdBCG() {
		return dBCG;
	}
	public void setdBCG(String dBCG) {
		this.dBCG = dBCG;
	}
	public String getdOPV0() {
		return dOPV0;
	}
	public void setdOPV0(String dOPV0) {
		this.dOPV0 = dOPV0;
	}
	public String getdHepB1() {
		return dHepB1;
	}
	public void setdHepB1(String dHepB1) {
		this.dHepB1 = dHepB1;
	}
	public String getdDTwP1() {
		return dDTwP1;
	}
	public void setdDTwP1(String dDTwP1) {
		this.dDTwP1 = dDTwP1;
	}
	public String getdIPV1() {
		return dIPV1;
	}
	public void setdIPV1(String dIPV1) {
		this.dIPV1 = dIPV1;
	}
	public String getdHepB2() {
		return dHepB2;
	}
	public void setdHepB2(String dHepB2) {
		this.dHepB2 = dHepB2;
	}
	public String getdRotavirus1() {
		return dRotavirus1;
	}
	public void setdRotavirus1(String dRotavirus1) {
		this.dRotavirus1 = dRotavirus1;
	}
	public String getdPCV2() {
		return dPCV2;
	}
	public void setdPCV2(String dPCV2) {
		this.dPCV2 = dPCV2;
	}
	public String getdDTwP2() {
		return dDTwP2;
	}
	public void setdDTwP2(String dDTwP2) {
		this.dDTwP2 = dDTwP2;
	}
	public String getdIPV2() {
		return dIPV2;
	}
	public void setdIPV2(String dIPV2) {
		this.dIPV2 = dIPV2;
	}
	public String getdHibB1() {
		return dHibB1;
	}
	public void setdHibB1(String dHibB1) {
		this.dHibB1 = dHibB1;
	}
	public String getdRva() {
		return dRva;
	}
	public void setdRva(String dRva) {
		this.dRva = dRva;
	}
	public String getdDTwP3() {
		return dDTwP3;
	}
	public void setdDTwP3(String dDTwP3) {
		this.dDTwP3 = dDTwP3;
	}
	public String getdIPV3() {
		return dIPV3;
	}
	public void setdIPV3(String dIPV3) {
		this.dIPV3 = dIPV3;
	}
	public String getdHib3() {
		return dHib3;
	}
	public void setdHib3(String dHib3) {
		this.dHib3 = dHib3;
	}
	public String getdRotavirus3() {
		return dRotavirus3;
	}
	public void setdRotavirus3(String dRotavirus3) {
		this.dRotavirus3 = dRotavirus3;
	}
	public String getdPCV3() {
		return dPCV3;
	}
	public void setdPCV3(String dPCV3) {
		this.dPCV3 = dPCV3;
	}
	public String getdOPV1() {
		return dOPV1;
	}
	public void setdOPV1(String dOPV1) {
		this.dOPV1 = dOPV1;
	}
	public String getdHepB3() {
		return dHepB3;
	}
	public void setdHepB3(String dHepB3) {
		this.dHepB3 = dHepB3;
	}
	public String getdOPV2() {
		return dOPV2;
	}
	public void setdOPV2(String dOPV2) {
		this.dOPV2 = dOPV2;
	}
	public String getdMMR1() {
		return dMMR1;
	}
	public void setdMMR1(String dMMR1) {
		this.dMMR1 = dMMR1;
	}
	public String getdTyphoidConjugate() {
		return dTyphoidConjugate;
	}
	public void setdTyphoidConjugate(String dTyphoidConjugate) {
		this.dTyphoidConjugate = dTyphoidConjugate;
	}
	public String getdHepA1() {
		return dHepA1;
	}
	public void setdHepA1(String dHepA1) {
		this.dHepA1 = dHepA1;
	}
	public String getdMMR2() {
		return dMMR2;
	}
	public void setdMMR2(String dMMR2) {
		this.dMMR2 = dMMR2;
	}
	public String getdVaricella1() {
		return dVaricella1;
	}
	public void setdVaricella1(String dVaricella1) {
		this.dVaricella1 = dVaricella1;
	}
	public String getdPCVBooster() {
		return dPCVBooster;
	}
	public void setdPCVBooster(String dPCVBooster) {
		this.dPCVBooster = dPCVBooster;
	}
	public String getdDTwPB1DTapB1() {
		return dDTwPB1DTapB1;
	}
	public void setdDTwPB1DTapB1(String dDTwPB1DTapB1) {
		this.dDTwPB1DTapB1 = dDTwPB1DTapB1;
	}
	public String getdIPVB1() {
		return dIPVB1;
	}
	public void setdIPVB1(String dIPVB1) {
		this.dIPVB1 = dIPVB1;
	}
	public String getdHepA2() {
		return dHepA2;
	}
	public void setdHepA2(String dHepA2) {
		this.dHepA2 = dHepA2;
	}
	public String getdTyphoidBooster1() {
		return dTyphoidBooster1;
	}
	public void setdTyphoidBooster1(String dTyphoidBooster1) {
		this.dTyphoidBooster1 = dTyphoidBooster1;
	}
	public String getdDTwPB2DTapB2() {
		return dDTwPB2DTapB2;
	}
	public void setdDTwPB2DTapB2(String dDTwPB2DTapB2) {
		this.dDTwPB2DTapB2 = dDTwPB2DTapB2;
	}
	public String getdOPV3() {
		return dOPV3;
	}
	public void setdOPV3(String dOPV3) {
		this.dOPV3 = dOPV3;
	}
	public String getdVericella2() {
		return dVericella2;
	}
	public void setdVericella2(String dVericella2) {
		this.dVericella2 = dVericella2;
	}
	public String getdTyphoidBooster2() {
		return dTyphoidBooster2;
	}
	public void setdTyphoidBooster2(String dTyphoidBooster2) {
		this.dTyphoidBooster2 = dTyphoidBooster2;
	}
	public String getdTdapTd() {
		return dTdapTd;
	}
	public void setdTdapTd(String dTdapTd) {
		this.dTdapTd = dTdapTd;
	}
	public String getdHPV1() {
		return dHPV1;
	}
	public void setdHPV1(String dHPV1) {
		this.dHPV1 = dHPV1;
	}
	public String getdHPV2() {
		return dHPV2;
	}
	public void setdHPV2(String dHPV2) {
		this.dHPV2 = dHPV2;
	}
	public String getdHDHIP() {
		return dHDHIP;
	}
	public void setdHDHIP(String dHDHIP) {
		this.dHDHIP = dHDHIP;
	}
	public String getdHIBB11() {
		return dHIBB11;
	}
	public void setdHIBB11(String dHIBB11) {
		this.dHIBB11 = dHIBB11;
	}
	public String getdPCV22() {
		return dPCV22;
	}
	public void setdPCV22(String dPCV22) {
		this.dPCV22 = dPCV22;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBCG() {
		return BCG;
	}
	public void setBCG(String bCG) {
		BCG = bCG;
	}
	public String getOPV0() {
		return OPV0;
	}
	public void setOPV0(String oPV0) {
		OPV0 = oPV0;
	}
	public String getHepB1() {
		return HepB1;
	}
	public void setHepB1(String hepB1) {
		HepB1 = hepB1;
	}
	public String getDTwP1() {
		return DTwP1;
	}
	public void setDTwP1(String dTwP1) {
		DTwP1 = dTwP1;
	}
	public String getIPV1() {
		return IPV1;
	}
	public void setIPV1(String iPV1) {
		IPV1 = iPV1;
	}
	public String getHepB2() {
		return HepB2;
	}
	public void setHepB2(String hepB2) {
		HepB2 = hepB2;
	}
	public String getRotavirus1() {
		return Rotavirus1;
	}
	public void setRotavirus1(String rotavirus1) {
		Rotavirus1 = rotavirus1;
	}
	public String getPCV2() {
		return PCV2;
	}
	public void setPCV2(String pCV2) {
		PCV2 = pCV2;
	}
	public String getDTwP2() {
		return DTwP2;
	}
	public void setDTwP2(String dTwP2) {
		DTwP2 = dTwP2;
	}
	public String getIPV2() {
		return IPV2;
	}
	public void setIPV2(String iPV2) {
		IPV2 = iPV2;
	}
	public String getHibB1() {
		return HibB1;
	}
	public void setHibB1(String hibB1) {
		HibB1 = hibB1;
	}
	
	public String getRva() {
		return Rva;
	}
	public void setRva(String rva) {
		Rva = rva;
	}
	public String getHDHIP() {
		return HDHIP;
	}
	public void setHDHIP(String hDHIP) {
		HDHIP = hDHIP;
	}
	public String getHIBB11() {
		return HIBB11;
	}
	public void setHIBB11(String hIBB11) {
		HIBB11 = hIBB11;
	}
	public String getPCV22() {
		return PCV22;
	}
	public void setPCV22(String pCV22) {
		PCV22 = pCV22;
	}
	public String getDTwP3() {
		return DTwP3;
	}
	public void setDTwP3(String dTwP3) {
		DTwP3 = dTwP3;
	}
	public String getIPV3() {
		return IPV3;
	}
	public void setIPV3(String iPV3) {
		IPV3 = iPV3;
	}
	public String getHib3() {
		return Hib3;
	}
	public void setHib3(String hib3) {
		Hib3 = hib3;
	}
	public String getRotavirus3() {
		return Rotavirus3;
	}
	public void setRotavirus3(String rotavirus3) {
		Rotavirus3 = rotavirus3;
	}
	public String getPCV3() {
		return PCV3;
	}
	public void setPCV3(String pCV3) {
		PCV3 = pCV3;
	}
	public String getOPV1() {
		return OPV1;
	}
	public void setOPV1(String oPV1) {
		OPV1 = oPV1;
	}
	public String getHepB3() {
		return HepB3;
	}
	public void setHepB3(String hepB3) {
		HepB3 = hepB3;
	}
	public String getOPV2() {
		return OPV2;
	}
	public void setOPV2(String oPV2) {
		OPV2 = oPV2;
	}
	public String getMMR1() {
		return MMR1;
	}
	public void setMMR1(String mMR1) {
		MMR1 = mMR1;
	}
	public String getTyphoidConjugate() {
		return TyphoidConjugate;
	}
	public void setTyphoidConjugate(String typhoidConjugate) {
		TyphoidConjugate = typhoidConjugate;
	}
	public String getHepA1() {
		return HepA1;
	}
	public void setHepA1(String hepA1) {
		HepA1 = hepA1;
	}
	public String getMMR2() {
		return MMR2;
	}
	public void setMMR2(String mMR2) {
		MMR2 = mMR2;
	}
	public String getVaricella1() {
		return Varicella1;
	}
	public void setVaricella1(String varicella1) {
		Varicella1 = varicella1;
	}
	public String getPCVBooster() {
		return PCVBooster;
	}
	public void setPCVBooster(String pCVBooster) {
		PCVBooster = pCVBooster;
	}
	public String getDTwPB1DTapB1() {
		return DTwPB1DTapB1;
	}
	public void setDTwPB1DTapB1(String dTwPB1DTapB1) {
		DTwPB1DTapB1 = dTwPB1DTapB1;
	}
	public String getIPVB1() {
		return IPVB1;
	}
	public void setIPVB1(String iPVB1) {
		IPVB1 = iPVB1;
	}
	public String getHepA2() {
		return HepA2;
	}
	public void setHepA2(String hepA2) {
		HepA2 = hepA2;
	}
	public String getTyphoidBooster1() {
		return TyphoidBooster1;
	}
	public void setTyphoidBooster1(String typhoidBooster1) {
		TyphoidBooster1 = typhoidBooster1;
	}
	public String getDTwPB2DTapB2() {
		return DTwPB2DTapB2;
	}
	public void setDTwPB2DTapB2(String dTwPB2DTapB2) {
		DTwPB2DTapB2 = dTwPB2DTapB2;
	}
	public String getOPV3() {
		return OPV3;
	}
	public void setOPV3(String oPV3) {
		OPV3 = oPV3;
	}
	public String getVericella2() {
		return Vericella2;
	}
	public void setVericella2(String vericella2) {
		Vericella2 = vericella2;
	}
	public String getTyphoidBooster2() {
		return TyphoidBooster2;
	}
	public void setTyphoidBooster2(String typhoidBooster2) {
		TyphoidBooster2 = typhoidBooster2;
	}
	public String getTdapTd() {
		return TdapTd;
	}
	public void setTdapTd(String tdapTd) {
		TdapTd = tdapTd;
	}
	public String getHPV1() {
		return HPV1;
	}
	public void setHPV1(String hPV1) {
		HPV1 = hPV1;
	}
	public String getHPV2() {
		return HPV2;
	}
	public void setHPV2(String hPV2) {
		HPV2 = hPV2;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getFileFileName() {
		return fileFileName;
	}
	public void setFileFileName(String fileFileName) {
		this.fileFileName = fileFileName;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
	
	
	
}
