package Vaccine;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import connection.HibernateConnection;

public class VaccinationImpl {

	public int addVChart(VaccineChart v) {
		int id=0;
		try{
			Session s1=HibernateConnection.getSessionFactory().openSession();
			List<VaccineChart> va=new ArrayList<VaccineChart>(1000);
		Query q=s1.createQuery("From VaccineChart where pid='"+v.getPid()+"'");
		va=q.list();
		if(va.size()>0) {
			for(VaccineChart vc:va) {
				id=vc.getId();
				System.out.println("list size is :"+va.size()+" id is : " +id);
			}
		}
		else {
		s1.save(v);
		s1.beginTransaction().commit();
		}
		s1.close();
		
		}
		catch (Exception e) {e.printStackTrace();
		}
		
		return id;
	}

	public int editVaccine(VaccineChart vc,int id) {
		int i=0;
		
		try{
			Session s=HibernateConnection.getSessionFactory().openSession();
			VaccineChart ty=(VaccineChart)s.load(VaccineChart.class, id);
			vc.setId(id);
			s.update(vc);
			
			s.beginTransaction().commit();
			s.close();
			}
		catch (Exception e) {e.printStackTrace();
		}
		return i;
		
	}
	public List<VaccineChart> viewChart(String id) {
		List<VaccineChart> v=new ArrayList<VaccineChart>(1000);
		try{
			Session s=HibernateConnection.getSessionFactory().openSession();
		//Criteria q=s.createCriteria(VaccineChart.class).add(Restrictions.ilike("pid", id));
		Query q=s.createQuery("From VaccineChart where pid='"+id+"'");
			v=q.list();
		s.close();
		}
		catch (Exception e) {e.printStackTrace();
		}
		return v;
	}

}
